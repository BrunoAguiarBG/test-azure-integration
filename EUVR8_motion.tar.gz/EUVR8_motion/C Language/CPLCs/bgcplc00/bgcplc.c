/*For more information see notes.txt in the Documentation folder */
#include <gplib.h>
#include <stdio.h>
#include <dlfcn.h>

#define _PPScriptMode_		// for enum mode, replace this with #define _EnumMode_	

#include "../../Include/pp_proj.h"

void user_plcc()
{	
	FastSave();
	pshm->UserAlgo.BgCplc[0] = 0;
}
