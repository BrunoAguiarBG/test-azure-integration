#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <time.h>
#include <gplib.h>   // Global Gp Shared memory pointer
#include "../../Include/pp_proj.h"


#include <RtGpShm.h>	// Global Rt/Gp Shared memory pointers

#define MaxPendng		5    /* Max connection requests */
#define BufferSize		4096
#define	MAX_CMDLINE		256
#define GPASCII_OUT     "/tmp/gpascii_out"
#define GPASCII_ERR     "/tmp/gpascii_err"

char command[BufferSize] = {0x0};
char response[BufferSize] = {0x0};
char errmsg[BufferSize] = {0x0};
char tmpstr[BufferSize] = {0x0};
char cmdline[BufferSize] = {0x0};

char *ack = NULL;
char *errstr = NULL;

FILE *pipein_fp, *pipeout_fp;

int counter, resp_flag=0, err_file_size;

void Die(char *mess) { perror(mess); exit(1); }

// Prototypes
void HandleClient(int sock);

int main(int argc, char *argv[])
{
	int serversock, clientsock;
	struct sockaddr_in server, client;

	struct timespec sleeptime = {0};
	sleeptime.tv_nsec = 10*1000*1000; /* 10 msec */ 
 
	InitLibrary();

    unlink(GPASCII_OUT);
    if (( pipeout_fp = fopen(GPASCII_OUT,"w+")) == NULL)
    {
            perror("fopen");
            exit(1);
    }

    while ( (access(GPASCII_OUT, F_OK) == -1) )
    {
        nanosleep(&sleeptime,NULL);
        counter++;
        if( counter > 500) /* 5 sec. */
        {
            printf("Either %s or %s are not created. Exiting ... \n", GPASCII_OUT, GPASCII_ERR);
            exit(-1);
        }
    }

    /* Create one way pipe line with call to popen() */

    sprintf(cmdline, "/usr/bin/gpascii -2 -f >%s 2>&1", GPASCII_OUT);    

    if (( pipein_fp = popen(cmdline, "w")) == NULL)
    {
            perror("popen");
            exit(1);
    }
        
    // Discard gpascii banner
    while(errstr == 0)
    {
        errstr = strstr(response,"STDIN Open for ASCII Input");
        fgets(response, BufferSize, pipeout_fp);
    }
    //printf("[debug] banner: %s\n", response);
    errstr = NULL;
    
    // reset out and err files
    truncate(GPASCII_OUT, 0);
        
     
	 /* Create the TCP socket */
	 if ((serversock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) 
	 {
		Die("Failed to create socket");
	 }

	 // Construct the server sockaddr_in structure 
	 memset(&server, 0, sizeof(server));       /* Clear struct */
	 server.sin_family = AF_INET;                  /* Internet/IP */
	 server.sin_addr.s_addr = htonl(INADDR_ANY);   /* Incoming addr */
	 server.sin_port = htons(10240);

	// Bind the server socket 
	if (bind(serversock, (struct sockaddr *) &server, sizeof(server)) < 0) 
	{
		Die("Failed to bind the server socket");	
	}

	// Listen on the server socket 
	if (listen(serversock, MaxPendng) < 0) 
	{
		Die("Failed to listen on server socket");
	}
   
	// Run until cancelled 
	while (1) 
	{
		unsigned int clientlen = sizeof(client);
		// Wait for client connection 
		if ((clientsock = accept(serversock, (struct sockaddr *) &client, &clientlen)) < 0) 
		{
			Die("Failed to accept client connection");
		}
		fprintf(stdout, "Client connected: %s\n", inet_ntoa(client.sin_addr));
		HandleClient(clientsock);
	}

     pclose(pipein_fp);
     pclose(pipeout_fp);
         
     CloseLibrary();    
     return 0;
 }


  // HandleClient operates once the server accepts connection with the client
void HandleClient(int sock) 
{
	char buffer[BufferSize];
	char outstr[BufferSize];
	char response[BufferSize];
	int returnDataLength;
	int received = -1, i;
	char* p;

	memset(buffer, 0, sizeof(buffer));

	 /* Receive message */
	if ((received = recv(sock, buffer, BufferSize, 0)) < 0) 
	{
		Die("Failed to receive initial bytes from client");
	}

	 /* Send bytes and check for more incoming data in loop */
	while (received > 0) 
	{
	    // printf("OK_1");
	    /* send command to PMAC and get response */
		//GetResponse(buffer, outstr, BufferSize, 7);  // get response from PPMAC command preprocessor
		fputs(buffer, pipein_fp);
        fputc('\n', pipein_fp);
        fflush(pipein_fp);
		
		memset(outstr, 0, sizeof(outstr));
		memset(response, 0, sizeof(response));

		//printf("Sent command:[%s]\n", buffer);
        //printf("Received response:\n------------------\n");

		while(ack == NULL)
        {
            memset(response,0,(size_t) BufferSize);
            if ( fgets(response, BufferSize, pipeout_fp) !=NULL )
            {
                ack=strchr(response,'\006');
                if( ack == NULL)
                {
                    sprintf(tmpstr, "%s", response);
                    
                    errstr = strstr (tmpstr,"stdin:");
                    if ( errstr != NULL)
                    {
                        strcpy( errmsg , tmpstr);
						strcat(outstr, tmpstr);
                    } 
					else 
					{
                        //printf("%s", tmpstr);				
						strcat(outstr, tmpstr);
						resp_flag = 1;
					} 
				}
				/*
				else 
				{
                    if(!resp_flag)
                    {
                        printf("NO_RESP\n"); // no response, e.g only <ACK>
                    }
                }
				*/
            } 
        }
  
		fflush(pipeout_fp);
		fgets(response, BufferSize, pipeout_fp); // to have for having 2x consecutive commands working ??
        ack = NULL;
		resp_flag = 0;

        if ( err_file_size || errstr)   
        {
            sprintf(tmpstr, "%s", errmsg);
            printf("%s", tmpstr);
        } else {
            printf("NO_ERR\n");
        }                       
                
        //printf("\n------------------\n");

        truncate(GPASCII_OUT, 0);
	
////Lucio_______________________________________________________________
//		// Replace LF by CRLF
//		// to have one value per line
//		// in case of multiple values feedback (like i.e. "p1..10")
//		int len  = strlen(outstr);
//		int lena = 1, lenb = 2;
//		for (p = outstr; p = strstr(p, "\n"); ++p) {
//			if (lena != lenb) // shift end as needed
//			{   
//				memmove(p+lenb, p+lena, len - (p - outstr) + lenb);
//			}
//			memcpy(p, "\n\r", lenb);
//			len  = strlen(outstr);
//		}
////Lucio_______________________________________________________________

//ZEISS_______________________________________________________________
    char* pointerInBuffer;		// Steffen: zeiger auf position array
    int ii = 0;
	char outstrMod[8192];
	   // add \r\n ----------------------------------------------------------------------------------------
	       // outstr erst mal leer machen
       for (ii = 0; ii < sizeof(outstr)-1; ii++)
       {
             outstrMod[ii] = '\0';
       }
       // l�nge von buffer ermitteltn, dann wissen wir wie lange die nachricht ist
       int len = strlen(outstr);
       // die nachricht kopieren wir dann in den outstr
       memcpy(outstrMod, outstr, len-1);
       // wir setzen den pointer auf den anfang des outstr
       pointerInBuffer = outstrMod;
       // jetzt wird der pointer auf das letzte zeichen unserer nachricht gesetzt
       pointerInBuffer += len-1;
       // nun k�nnnen wir CR LF anf�gen
       memcpy(pointerInBuffer, "\r\n", 2);
//ZEISS_______________________________________________________________

		/*
		// to debug and see ascii of sting in console
		for(i=0; outstr[i]!='\0'; i++){
			fprintf(stdout,"%02X \n",outstr[i]);
		}
		*/




		/* Send back received data */
////Lucio		
//		returnDataLength = strlen(outstr);	
//ZEISS
		returnDataLength = strlen(outstrMod);	
////Lucio
//		if (send(sock, outstr, returnDataLength, 0) != returnDataLength) 
//ZEISS
		if (send(sock, outstrMod, returnDataLength, 0) != returnDataLength) 
		{
			Die("Failed to send bytes to client");
		}
		memset(buffer, 0, sizeof(buffer));
		/* Check for more data */
		if ((received = recv(sock, buffer, BufferSize, 0)) < 0) 
		{
			Die("Failed to receive additional bytes from client");
		}
	}
	close(sock);
}


