#include <stdio.h>
 #include <sys/socket.h>
 #include <arpa/inet.h>
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
 #include <netinet/in.h>
 #include <gplib.h>   // Global Gp Shared memory pointer
 #include "../../Include/pp_proj.h"

 #include <RtGpShm.h>	// Global Rt/Gp Shared memory pointers

 #define MAXPENDING 5    /* Max connection requests */
 #define BUFFSIZE 8192 //128
 #define BUFFSIZE1 8192 //128
 void Die(char *mess) { perror(mess); exit(1); }

 // Prototypes
 void HandleClient(int sock);

 int main(int argc, char *argv[]) {
 {
 int serversock, clientsock;
 struct sockaddr_in server, client;
 InitLibrary();
 /*
 if (argc != 2) {
   fprintf(stderr, "USAGE: server <port>\n"); // Can pass any port here; 10006 works usually
   exit(1);
 }
 */
     
 /* Create the TCP socket */
 if ((serversock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
   Die("Failed to create socket");
 }
 // Construct the server sockaddr_in structure 
 memset(&server, 0, sizeof(server));       /* Clear struct */
 server.sin_family = AF_INET;                  /* Internet/IP */
 server.sin_addr.s_addr = htonl(INADDR_ANY);   /* Incoming addr */
 server.sin_port = htons(10006);

 // Bind the server socket 
 if (bind(serversock, (struct sockaddr *) &server,
                            sizeof(server)) < 0) {
 Die("Failed to bind the server socket");
 }
 // Listen on the server socket 
 if (listen(serversock, MAXPENDING) < 0) {
 Die("Failed to listen on server socket");
 }
   
 // Run until cancelled 
 while (1) {
   unsigned int clientlen = sizeof(client);
   // Wait for client connection 
   if ((clientsock =
        accept(serversock, (struct sockaddr *) &client,
               &clientlen)) < 0) {
     Die("Failed to accept client connection");
   }
   fprintf(stdout, "Client connected: %s\n",
                   inet_ntoa(client.sin_addr));
   HandleClient(clientsock);
 }
 }
           
     CloseLibrary();    
     return 0;
 }
 
  // HandleClient operates once the server accepts connection with the client
void HandleClient(int sock) 
{
	char buffer[BUFFSIZE];
	char outstr[BUFFSIZE1];

	int returnDataLength;
	int received = -1, i;
	char* p;

    char* pointerInBuffer;		// Steffen: zeiger auf position array
    int ii = 0;
	char outstrMod[BUFFSIZE1];

	memset(buffer, 0, sizeof(buffer));

	 /* Receive message */
	if ((received = recv(sock, buffer, BUFFSIZE, 0)) < 0) 
	{
		Die("Failed to receive initial bytes from client");
	}

	 /* Send bytes and check for more incoming data in loop */
	while (received > 0) 
	{
	    /* send command to PMAC and get response */
		GetResponse(buffer, outstr, BUFFSIZE1, 7);  // get response from PPMAC command preprocessor

		// Replace "," by "LF" -----------------------------------------------------------------------------
		// to have same response: one value per line
		// also in case of multiple values feedback (like i.e. "P1, 20" which would get comma seperation)

/*		int len  = strlen(outstr);
		int lena = 1, lenb = 2;
		for (p = outstr; p = strstr(p, ","); ++p) {
			if (lena != lenb) // shift end as needed
			{   
				memmove(p+lenb, p+lena, len - (p - outstr) + lenb);
			}
			memcpy(p, "\n", lenb
			len  = strlen(outstr);
		}*/


	   // add \r\n ----------------------------------------------------------------------------------------
	       // outstr erst mal leer machen
       for (ii = 0; ii < sizeof(outstr)-1; ii++)
       {
             outstrMod[ii] = '\0';
       }
       // l�nge von buffer ermitteltn, dann wissen wir wie lange die nachricht ist
       int len = strlen(outstr);
       // die nachricht kopieren wir dann in den outstr
       memcpy(outstrMod, outstr, len-1);
       // wir setzen den pointer auf den anfang des outstr
       pointerInBuffer = outstrMod;
       // jetzt wird der pointer auf das letzte zeichen unserer nachricht gesetzt
       pointerInBuffer += len-1;
       // nun k�nnnen wir CR LF anf�gen
       memcpy(pointerInBuffer, "\r\n", 2);


		/*
		// to debug and see ascii of sting in console
		for(i=0; outstr[i]!='\0'; i++){
			fprintf(stdout,"%02X \n",outstr[i]);
		}
*/

		/* Send back received data */
		returnDataLength = strlen(outstrMod);

		if (send(sock, outstrMod, returnDataLength, 0) != returnDataLength) 
		{
			Die("Failed to send bytes to client");
		}

		memset(buffer, 0, sizeof(buffer));

		/* Check for more data */
		if ((received = recv(sock, buffer, BUFFSIZE, 0)) < 0) 
		{
			Die("Failed to receive additional bytes from client");
		}
	}
	close(sock);
}


